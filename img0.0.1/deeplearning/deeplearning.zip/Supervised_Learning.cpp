#include "Supervised_Learning.h"
#include <iostream>
using namespace std;
 
//Splearnging Sp;

Splearnging::Splearnging()
{

};


Splearnging::~Splearnging()
{

};
#if 0

template<typename _Tp>
void Splearnging::logistic_regression(const Mat& theta, Mat& X, Mat& y, double &f, Mat& g)
{
	y = 0;
	int m = X.cols;
	//Mat tmp()
}

template<typename _Tp>
void Splearnging::linear_regression(Mat& theta, Mat& X, Mat& y, double &f, Mat &g)
{
	if (1 != theta.cols || 0 == theta.rows) {
		cout << "��������ֹһ��" << endl; return;
	};
	int m = X.cols;
	int n = X.rows;
	f = 0;
	Mat l_mat(theta.rows, theta.rows, _Tp, Scalar(0));
	g = l_mat.clone();
}

template<typename _Tp>
void Splearnging::linear_regression_vec(Mat& theta, Mat& X, Mat& y, double &f, Mat &g)
{
	if (1 != theta.cols || 0 == theta.rows) {
		cout << "��������ֹһ��" << endl; return;
	};
	int m = X.cols;
	//n = 0;
	f = 0;
	Mat l_mat(theta.rows, theta.rows, CV_64FC1, Scalar(0));
	l_mat.at<double>(12, 5);
	g = l_mat.clone();
}

#endif