#pragma once 
#include "../source.h"
#include "exMath.h"
#include <iostream>
#include <vector>

#ifdef _WIN64
	#define	IMAGE_API __declspec(dllexport)
#else
	#define	IMAGE_API __declspec(dllexport)
#endif




//extern Splearnging Sp;